﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(textBox1.Text);
            int sum = 0;
            if (a > 0)
            {
                if (comboBox1.SelectedIndex == 0)
                {
                    sum = sum + 300 + (a * 100);
                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    sum = sum + 500 + (a * 100);
                }
                else
                {
                    sum = sum + 700 + (a * 100);
                }

            }
            textBox2.Text = Convert.ToString(sum);
        }
    }
}
