﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(textBox1.Text);
            int sum = 0;
            if (a > 1)
            {
                if (comboBox1.SelectedIndex == 0)
                {
                    sum = sum + 1000;
                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    sum = sum + 750;
                }
                else
                {
                    sum = sum + 500;
                }
                // textBox2.Text = Convert.ToString(sum);
               
            }
           else
            {
                sum = sum + 250;
            }
            textBox2.Text = Convert.ToString(sum);
        }
    }
}
