﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMIasadov
{
    public partial class Form3 : Form
    {
     
       
        public Form3()
        {
            InitializeComponent();          
        }

        private void button2_Click(object sender, EventArgs e)
        {
          
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            double ves = double.Parse(textBox2.Text);
            double rost = double.Parse(textBox1.Text);
            double vozrast = double.Parse(textBox3.Text);
            double BMRM = (66 + (13.7 * ves) + (5 * rost) - (6.8 * vozrast));
            label18.Text = Convert.ToString(BMRM * 1.2);
            label19.Text = Convert.ToString(BMRM * 1.375);
            label20.Text = Convert.ToString(BMRM * 1.55);
            label21.Text = Convert.ToString(BMRM * 1.725);
            label22.Text = Convert.ToString(BMRM * 1.9);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            double ves = double.Parse(textBox2.Text);
            double rost = double.Parse(textBox1.Text);
            double vozrast = double.Parse(textBox3.Text);
            double BMRW = 655 + (9.6 * ves) + (1.8 * rost) - (4.7 * vozrast);
            label18.Text = Convert.ToString(BMRW * 1.2);
            label19.Text = Convert.ToString(BMRW * 1.375);
            label20.Text = Convert.ToString(BMRW * 1.55);
            label21.Text = Convert.ToString(BMRW * 1.725);
            label22.Text = Convert.ToString(BMRW * 1.9);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            panel1.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
