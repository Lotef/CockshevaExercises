﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMIasadov
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double ves = double.Parse(textBox2.Text);
            double rost = double.Parse(textBox1.Text);
            double index = ves / ((rost / 100) * (rost / 100));
            label8.Text = index.ToString("##.##");
            trackBar1.Value = Convert.ToInt32(index); 
            if (index < 18.5)
            {
                pictureBox3.Image = Image.FromFile(@"C:\Users\student\source\repos\BMIasadov\BMIasadov\Resources\bmi-underweight-icon.png");
            }
            else if (index < 25)
            {
                pictureBox3.Image = Image.FromFile(@"C:\Users\student\source\repos\BMIasadov\BMIasadov\Resources\bmi-obese-icon.png");
            }
            else if (index < 30)
            {
                pictureBox3.Image = Image.FromFile(@"C:\Users\student\source\repos\BMIasadov\BMIasadov\Resources\bmi-overweight-icon.png");
            }
            else
            {
                pictureBox3.Image = Image.FromFile(@"C:\Users\student\source\repos\BMIasadov\BMIasadov\Resources\bmi-healthy-icon.png");
            }
        }
    }
}
